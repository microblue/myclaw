import { defineChannelPluginEntry, type OpenClawPluginApi } from "openclaw/plugin-sdk/core";
import { greatlovePlugin } from "./src/channel";
import { registerPairCli } from "./src/cli";
import { setGreatLoveRuntime } from "./src/runtime";

export { greatlovePlugin } from "./src/channel";
export { setGreatLoveRuntime } from "./src/runtime";

const DEFAULT_API_URL = "https://edaygteqqoqezshlxmmx.supabase.co/functions/v1/greatlove-plugin";

export default defineChannelPluginEntry({
  id: "greatlove",
  name: "GreatLove Channel",
  description: "GreatLove APP messaging channel integration",
  plugin: greatlovePlugin,
  setRuntime: setGreatLoveRuntime,
  registerFull(api: OpenClawPluginApi) {
    /**
     * Register `openclaw greatlove pair` CLI command. This runs at CLI parse time,
     * before any channel activation — so it's available even on a fresh install
     * where the user hasn't configured greatlove yet.
     */
    api.registerCli(registerPairCli as any, {
      commands: ["greatlove"],
      descriptors: [
        { name: "greatlove", description: "GreatLove APP pairing and info", hasSubcommands: true },
      ],
    });


    /**
     * Gateway method: greatlove.pair.start
     * Usage:
     *   openclaw gateway call greatlove.pair.start
     *
     * Returns: { code, watcherToken, apiUrl, expiresInSeconds, pollIntervalSeconds }
     * Plugin operator reads the 6-digit `code`, types it in GreatLove APP, then calls
     * greatlove.pair.wait to receive the pluginToken.
     */
    api.registerGatewayMethod("greatlove.pair.start", async ({ respond, params }) => {
      const apiUrl = typeof params?.apiUrl === "string" ? params.apiUrl : DEFAULT_API_URL;
      try {
        const r = await fetch(`${apiUrl.replace(/\/$/, "")}/pair/start`, { method: "POST" });
        if (!r.ok) {
          const body = await r.text().catch(() => "");
          respond(false, undefined, { code: "PAIR_START_HTTP", message: `/pair/start ${r.status}: ${body}` });
          return;
        }
        const data = (await r.json()) as Record<string, unknown>;
        respond(true, { ...data, apiUrl });
      } catch (err) {
        respond(false, undefined, { code: "PAIR_START_ERR", message: (err as Error).message });
      }
    });

    /**
     * Gateway method: greatlove.pair.wait
     * Usage:
     *   openclaw gateway call greatlove.pair.wait --params '{"code":"123456","watcherToken":"...","apiUrl":"..."}'
     *
     * Polls /pair/status for up to 5 min. Returns the pluginToken once the APP user
     * confirms. The operator should then persist the token via config or the
     * `channels.greatlove` section.
     */
    api.registerGatewayMethod("greatlove.pair.wait", async ({ respond, params }) => {
      const code = typeof params?.code === "string" ? params.code : "";
      const watcherToken = typeof params?.watcherToken === "string" ? params.watcherToken : "";
      const apiUrl = typeof params?.apiUrl === "string" ? params.apiUrl : DEFAULT_API_URL;
      if (!code || !watcherToken) {
        respond(false, undefined, { code: "BAD_PARAMS", message: "Missing code or watcherToken" });
        return;
      }
      const intervalMs =
        typeof params?.pollIntervalSeconds === "number" ? params.pollIntervalSeconds * 1000 : 2000;
      const deadline =
        Date.now() + (typeof params?.timeoutSeconds === "number" ? params.timeoutSeconds * 1000 : 5 * 60 * 1000);

      try {
        while (Date.now() < deadline) {
          await new Promise((r) => setTimeout(r, intervalMs));
          const r = await fetch(`${apiUrl.replace(/\/$/, "")}/pair/status`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code, watcherToken }),
          });
          const data = (await r.json().catch(() => ({}))) as {
            status?: string;
            pluginToken?: string;
            userId?: string;
            userEmail?: string;
          };
          if (data.status === "claimed") {
            respond(true, { ...data, apiUrl });
            return;
          }
          if (data.status === "expired") {
            respond(false, undefined, { code: "PAIR_EXPIRED", message: "Pairing code expired" });
            return;
          }
        }
        respond(false, undefined, { code: "PAIR_TIMEOUT", message: "Pairing timed out (5 min)" });
      } catch (err) {
        respond(false, undefined, { code: "PAIR_ERR", message: (err as Error).message });
      }
    });
  },
});
