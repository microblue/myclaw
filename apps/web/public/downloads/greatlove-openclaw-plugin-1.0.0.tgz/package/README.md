# GreatLove · OpenClaw Plugin

把 GreatLove APP 接到 OpenClaw AI 助手。用户在 APP 聊天，OpenClaw 驱动的 AI 后台回复。

---

## 🚀 用户怎么用

**在你 OpenClaw 的 dashboard chat 里说一句话就行。**

### 场景 A · 你的 OpenClaw 已经装了这个插件（托管版）

```
你：绑定 GreatLove
```

AI 会：
1. 请求一个 **6 位验证码**，显示给你
2. 让你打开 GreatLove APP → AI 助手 → 输入那 6 位
3. 自动等你确认、写配置、重启服务
4. 告诉你 **✅ 已绑定**

完事。之后 APP 里聊天，AI 秒回。

### 场景 B · 你的 OpenClaw 还没装插件（自助安装）

先把 [`docs/SELF_INSTALL_PROMPT.md`](./docs/SELF_INSTALL_PROMPT.md) 里的 **Phase 1 prompt** 粘进 chat，让 AI 自动装插件、重启 gateway。重启后**开一个新 chat**，然后按场景 A 说"绑定 GreatLove"。

> 自助安装需要你的 OpenClaw agent 后端是 `claude-cli`（有 Bash 工具）。API 直连后端装不了，找运营方帮装。

### 演示站（先体验不用自己装）

- 💬 **Web 聊天**（代替 GreatLove APP）：https://my-chat-seven-omega.vercel.app/
- 👤 账号：`microblue@gmail.com` / `GreatLoveDev2026!`（测试用）
- 🎯 AI 回复来自 `zqxgpd63.myclaw.one` 上的 GreatLove 托管 OpenClaw

---

## 📖 详细文档

| 我想… | 看这份 |
|---|---|
| 手把手走一遍完整流程（用户视角 + 运营视角） | [`docs/USER_GUIDE.md`](./docs/USER_GUIDE.md) |
| 托管版用户的绑定 prompt（场景 A 详解） | [`docs/INSTALL_PROMPT.md`](./docs/INSTALL_PROMPT.md) |
| 自助安装 prompt（场景 B 的两段话） | [`docs/SELF_INSTALL_PROMPT.md`](./docs/SELF_INSTALL_PROMPT.md) |
| 我是开发者，要改代码 / 部自己的后端 | [`CLAUDE.md`](./CLAUDE.md) + [`docs/DEVELOPMENT.md`](./docs/DEVELOPMENT.md) |

---

## 🧩 这个插件是啥

```
GreatLove APP  ──write messages──▶  Supabase
      ▲                                 │
      │                                 │ Realtime
      │ read replies                    ▼
      │                         ┌──────────────┐
      └─────────────────────────│  OpenClaw    │
                                │  + 这个插件  │
                                │  + AI Agent  │
                                └──────────────┘
```

- **Supabase** 存消息 + 分发 Realtime 事件
- **插件**订阅 Realtime，把用户消息交给 OpenClaw 的 AI，AI 回复写回 `replies` 表
- **APP** 读写 Supabase 即可，不直接连 OpenClaw

技术细节见 [`CLAUDE.md`](./CLAUDE.md)。

---

## 🔐 安全模型一行话

用户只握一个可吊销的 `pluginToken`（APP 里 revoke 1 分钟生效）。Supabase service_role 永远不离开 Edge Function 和运维 daemon。细节 [`CLAUDE.md`](./CLAUDE.md) 里有。

---

## 链接

- 📦 GitHub repo：https://github.com/microblue/claw-greatlove-plugin
- 🔎 问题反馈：https://github.com/microblue/claw-greatlove-plugin/issues
- 🏠 参考 OpenClaw：https://openclaw.ai
