/**
 * GreatLove Setup Wizard
 *
 * Hooks into `openclaw configure` / `openclaw channels login --channel greatlove` /
 * the OpenClaw dashboard to provide an interactive pairing flow instead of asking
 * the user to paste apiUrl + pluginToken manually.
 *
 * Flow inside prepare():
 *   1. POST {apiUrl}/pair/start                  → {code, watcherToken}
 *   2. prompter.note displays the 6-digit code
 *   3. prompter.progress shows "waiting..."
 *   4. poll {apiUrl}/pair/status every 2s
 *   5. on status=claimed, return modified cfg with apiUrl+pluginToken filled in
 */

// Production GreatLove Supabase Edge Function. To point at a custom deployment,
// pre-fill cfg.channels.greatlove.apiUrl before running configure.
const DEFAULT_API_URL = "https://edaygteqqoqezshlxmmx.supabase.co/functions/v1/greatlove-plugin";

interface PairStartResp {
  code: string;
  watcherToken: string;
  expiresInSeconds?: number;
  pollIntervalSeconds?: number;
}

interface PairStatusResp {
  status: "pending" | "claimed" | "expired" | string;
  pluginToken?: string;
  userId?: string;
  userEmail?: string;
  error?: string;
}

async function startPairing(apiUrl: string): Promise<PairStartResp> {
  const r = await fetch(`${apiUrl.replace(/\/$/, "")}/pair/start`, { method: "POST" });
  if (!r.ok) {
    const body = await r.text().catch(() => "");
    throw new Error(`/pair/start ${r.status}: ${body}`);
  }
  return (await r.json()) as PairStartResp;
}

async function pollPairing(
  apiUrl: string,
  code: string,
  watcherToken: string,
): Promise<PairStatusResp> {
  const r = await fetch(`${apiUrl.replace(/\/$/, "")}/pair/status`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code, watcherToken }),
  });
  const data = (await r.json()) as PairStatusResp;
  if (!r.ok && !data?.status) {
    throw new Error(data?.error || `pair/status ${r.status}`);
  }
  return data;
}

function applyPairingToCfg(
  cfg: any,
  accountId: string,
  apiUrl: string,
  pluginToken: string,
): any {
  const nextCfg: any = { ...cfg };
  const channels = { ...(cfg?.channels ?? {}) };
  const existing = { ...(channels.greatlove ?? {}) };

  if (!accountId || accountId === "default") {
    channels.greatlove = {
      ...existing,
      apiUrl,
      pluginToken,
      enabled: true,
    };
  } else {
    const accounts = { ...(existing.accounts ?? {}) };
    accounts[accountId] = {
      ...(accounts[accountId] ?? {}),
      apiUrl,
      pluginToken,
      enabled: true,
    };
    channels.greatlove = { ...existing, accounts };
  }

  nextCfg.channels = channels;
  return nextCfg;
}

/**
 * OpenClaw SetupWizard for greatlove channel.
 * (Typed as `any` because OpenClaw's exported types don't cleanly resolve across
 *  the plugin-sdk subpath boundary — runtime shape is what matters to the host.)
 */
export const greatloveSetupWizard: any = {
  channel: "greatlove",

  status: {
    configuredLabel: "已绑定 GreatLove APP",
    unconfiguredLabel: "未绑定",
    configuredHint: "已连接 GreatLove，可接收用户消息",
    unconfiguredHint: "用 APP 扫码完成绑定",
    configuredScore: 5,
    unconfiguredScore: 4,
    resolveConfigured: ({ cfg, accountId }: { cfg: any; accountId?: string }) => {
      const c = cfg?.channels?.greatlove;
      if (!c) return false;
      if (!accountId || accountId === "default") {
        return Boolean(c.apiUrl && c.pluginToken);
      }
      const acc = c.accounts?.[accountId];
      return Boolean((acc?.apiUrl ?? c.apiUrl) && (acc?.pluginToken ?? c.pluginToken));
    },
  },

  introNote: {
    title: "GreatLove",
    lines: [
      "把本地 OpenClaw 连接到你的 GreatLove APP 账号。",
      "配对只需要一次：终端会显示 6 位验证码，在 APP 里输入即可。",
    ],
  },

  prepare: async ({
    cfg,
    accountId,
    prompter,
  }: {
    cfg: any;
    accountId: string;
    prompter: any;
  }) => {
    const apiUrl =
      cfg?.channels?.greatlove?.accounts?.[accountId]?.apiUrl ||
      cfg?.channels?.greatlove?.apiUrl ||
      DEFAULT_API_URL;

    // Step 1: ask server for a pairing code
    let start: PairStartResp;
    try {
      start = await startPairing(apiUrl);
    } catch (err) {
      await prompter.note?.(
        [`请求服务器失败：${(err as Error).message}`, "", `检查网络或 apiUrl: ${apiUrl}`].join("\n"),
        "❌ 配对失败",
      );
      throw err;
    }

    const { code, watcherToken } = start;
    const ttl = start.expiresInSeconds ?? 300;
    const intervalMs = (start.pollIntervalSeconds ?? 2) * 1000;

    // Step 2: show code prominently
    const pretty = `${code.slice(0, 3)} ${code.slice(3)}`;
    await prompter.note?.(
      [
        "",
        "   在 GreatLove APP 中输入以下验证码：",
        "",
        `         ┌───────────────────┐`,
        `         │     ${pretty}     │`,
        `         └───────────────────┘`,
        "",
        `   ${ttl} 秒内有效`,
        "",
        "   步骤：",
        "   1. 打开 GreatLove APP（或 http://localhost:5500/pair.html）",
        "   2. 登录你的账号",
        "   3. 进入「绑定 OpenClaw」→ 输入上面 6 位数字",
      ].join("\n"),
      "验证码",
    );

    // Step 3: poll until claimed
    const progress = prompter.progress?.("等待 APP 确认...") ?? {
      update: (_: string) => {},
      stop: (_: string | undefined) => {},
    };

    const deadline = Date.now() + ttl * 1000;
    try {
      while (Date.now() < deadline) {
        await new Promise((r) => setTimeout(r, intervalMs));
        let st: PairStatusResp;
        try {
          st = await pollPairing(apiUrl, code, watcherToken);
        } catch (err) {
          progress.update?.(`查询失败：${(err as Error).message}，重试中…`);
          continue;
        }

        if (st.status === "claimed" && st.pluginToken) {
          const displayUser = st.userEmail || st.userId || "(unknown)";
          progress.stop?.(`✅ 已绑定 ${displayUser}`);

          // Return modified cfg — the OpenClaw setup runtime persists this on disk.
          return {
            cfg: applyPairingToCfg(cfg, accountId, apiUrl, st.pluginToken),
          };
        }

        if (st.status === "expired") {
          progress.stop?.("❌ 验证码已过期");
          throw new Error("验证码已过期，请重新运行 configure");
        }

        // pending — keep waiting (progress spinner stays)
      }

      progress.stop?.("❌ 超时");
      throw new Error("5 分钟内未完成配对");
    } catch (err) {
      progress.stop?.(`❌ ${(err as Error).message}`);
      throw err;
    }
  },

  // Our prepare does everything; no manual credential prompts needed.
  credentials: [],

  disable: (cfg: any) => {
    const c = cfg?.channels?.greatlove;
    if (!c) return cfg;
    return {
      ...cfg,
      channels: {
        ...cfg.channels,
        greatlove: { ...c, enabled: false },
      },
    };
  },
};

/**
 * Minimal SetupAdapter. Everything is done in the wizard's prepare(), so this just
 * returns cfg as-is.
 */
export const greatloveSetupAdapter: any = {
  applyAccountConfig: ({ cfg }: { cfg: any }) => cfg,
};
