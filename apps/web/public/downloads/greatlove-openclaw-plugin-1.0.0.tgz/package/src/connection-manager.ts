/**
 * GreatLove Realtime Connection Manager
 *
 * 流程：
 *   1. POST {apiUrl}/auth with Bearer <pluginToken>
 *      → { accessToken, expiresAt, userId, supabaseUrl, supabaseAnonKey }
 *   2. 用 supabase-js 直接连 Supabase Realtime WebSocket（长连接，不受 Edge Function wall-time 限制）
 *   3. 订阅 messages 表 INSERT，filter: conversation_id=eq.<userId>
 *   4. JWT 快过期前（剩 5 min）自动刷新，调用 realtime.setAuth 无缝续期
 *
 * 发消息（/send）和 ack（/ack）仍然走 Edge Function，这里不管。
 */
import { createClient, type RealtimeChannel, type SupabaseClient } from "@supabase/supabase-js";
import type {
  ConnectionState,
  GreatLoveConfig,
  GreatLoveInboundMessage,
  InboundMessagePayload,
} from "./types";
import { getLogger } from "./runtime";

interface AuthResponse {
  accessToken: string;
  refreshToken?: string;
  expiresAt: number;
  userId: string;
  email?: string;
  supabaseUrl: string;
  supabaseAnonKey: string;
}

export interface ConnectionManagerOptions {
  config: GreatLoveConfig;
  accountId: string;
  log?: any;
  onMessage: (message: GreatLoveInboundMessage) => void;
  onStateChange: (state: ConnectionState) => void;
}

export class ConnectionManager {
  private config: GreatLoveConfig;
  private accountId: string;
  private log: any;
  private onMessage: (message: GreatLoveInboundMessage) => void;
  private onStateChange: (state: ConnectionState) => void;

  private supabase: SupabaseClient | null = null;
  private channel: RealtimeChannel | null = null;
  private refreshTimer: NodeJS.Timeout | null = null;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private state: ConnectionState = "disconnected";
  private reconnectAttempts = 0;
  private readonly maxReconnectAttempts = 10;
  private stopped = false;
  private userId: string | null = null;
  private expiresAt = 0;

  constructor(options: ConnectionManagerOptions) {
    this.config = options.config;
    this.accountId = options.accountId;
    this.log = options.log ?? getLogger();
    this.onMessage = options.onMessage;
    this.onStateChange = options.onStateChange;
  }

  async start(): Promise<void> {
    this.stopped = false;
    await this.connect();
  }

  async stop(): Promise<void> {
    this.stopped = true;
    if (this.refreshTimer) clearTimeout(this.refreshTimer);
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.refreshTimer = null;
    this.reconnectTimer = null;

    if (this.channel && this.supabase) {
      await this.supabase.removeChannel(this.channel).catch(() => {});
    }
    if (this.supabase) {
      await this.supabase.realtime.disconnect();
    }
    this.channel = null;
    this.supabase = null;
    this.setState("disconnected");
  }

  private async connect(): Promise<void> {
    const { apiUrl, pluginToken } = this.config;
    if (!apiUrl || !pluginToken) {
      this.log?.error?.(`[GreatLove:${this.accountId}] Missing apiUrl or pluginToken`);
      this.setState("error");
      return;
    }

    this.setState("connecting");

    try {
      const auth = await this.fetchAuth();
      this.userId = auth.userId;
      this.expiresAt = auth.expiresAt;

      if (!this.supabase) {
        this.supabase = createClient(auth.supabaseUrl, auth.supabaseAnonKey, {
          auth: { persistSession: false, autoRefreshToken: false },
          realtime: { params: { eventsPerSecond: 10 } },
        });
      }
      this.supabase.realtime.setAuth(auth.accessToken);

      await this.subscribe();

      this.setState("connected");
      this.reconnectAttempts = 0;
      this.log?.info?.(`[GreatLove:${this.accountId}] Realtime connected, user=${auth.userId}`);

      this.scheduleRefresh();
    } catch (err: any) {
      this.log?.error?.(`[GreatLove:${this.accountId}] Connect error: ${err.message}`);
      this.scheduleReconnect();
    }
  }

  private async fetchAuth(): Promise<AuthResponse> {
    const { apiUrl, pluginToken } = this.config;
    const url = `${apiUrl!.replace(/\/$/, "")}/auth`;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${pluginToken}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      const body = await response.text().catch(() => "");
      throw new Error(`/auth HTTP ${response.status}: ${body}`);
    }

    const data = (await response.json()) as Partial<AuthResponse>;
    if (!data.accessToken || !data.userId || !data.supabaseUrl || !data.supabaseAnonKey || !data.expiresAt) {
      throw new Error("/auth response missing required fields");
    }
    return data as AuthResponse;
  }

  private async subscribe(): Promise<void> {
    if (!this.supabase || !this.userId) return;

    // 如果已有订阅，先清掉
    if (this.channel) {
      await this.supabase.removeChannel(this.channel).catch(() => {});
      this.channel = null;
    }

    const channelName = `plugin-${this.accountId}-${this.userId}`;
    const userId = this.userId;

    await new Promise<void>((resolve, reject) => {
      const channel = this.supabase!
        .channel(channelName)
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "messages",
            filter: `conversation_id=eq.${userId}`,
          },
          (payload) => {
            const row = payload.new as Record<string, unknown>;
            // 防御：bot 自己写的消息不往回传
            if (typeof row.sender_id === "string" && row.sender_id.startsWith("bot:")) return;
            this.handleInboundPayload({
              messageId: String(row.id),
              senderId: String(row.sender_id ?? ""),
              senderName: row.sender_name as string | undefined,
              conversationId: String(row.conversation_id ?? userId),
              content: String(row.content ?? ""),
              type: (row.type as InboundMessagePayload["type"]) ?? "text",
              mediaUrl: row.media_url as string | undefined,
              isGroup: Boolean(row.is_group ?? false),
              isMentioned: Boolean(row.is_mentioned ?? false),
              timestamp: row.created_at
                ? new Date(row.created_at as string).getTime()
                : Date.now(),
            });
          },
        )
        .subscribe((status, err) => {
          if (status === "SUBSCRIBED") {
            resolve();
          } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
            reject(err ?? new Error(`Subscription ${status}`));
          }
        });
      this.channel = channel;
    });
  }

  private handleInboundPayload(payload: InboundMessagePayload): void {
    const message: GreatLoveInboundMessage = {
      messageId: payload.messageId,
      senderId: payload.senderId,
      senderName: payload.senderName,
      conversationId: payload.conversationId,
      type: payload.type,
      text: payload.content,
      mediaUrl: payload.mediaUrl,
      isGroup: payload.isGroup,
      isMentioned: payload.isMentioned ?? false,
      timestamp: payload.timestamp,
      raw: payload,
    };
    this.onMessage(message);
  }

  /**
   * 在 JWT 过期前 5 分钟（或最晚过期前 60s）刷新
   */
  private scheduleRefresh(): void {
    if (this.refreshTimer) clearTimeout(this.refreshTimer);
    if (this.stopped) return;

    const msUntilExpiry = this.expiresAt - Date.now();
    const refreshIn = Math.max(msUntilExpiry - 5 * 60 * 1000, 60 * 1000);

    this.refreshTimer = setTimeout(async () => {
      if (this.stopped) return;
      try {
        const auth = await this.fetchAuth();
        this.expiresAt = auth.expiresAt;
        this.supabase?.realtime.setAuth(auth.accessToken);
        this.log?.debug?.(`[GreatLove:${this.accountId}] JWT refreshed`);
        this.scheduleRefresh();
      } catch (err: any) {
        this.log?.error?.(`[GreatLove:${this.accountId}] JWT refresh failed: ${err.message}`);
        // 刷新失败 → 重建整个连接
        this.scheduleReconnect();
      }
    }, refreshIn);
  }

  private scheduleReconnect(): void {
    if (this.stopped) return;
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      this.log?.error?.(`[GreatLove:${this.accountId}] Max reconnect attempts reached`);
      this.setState("error");
      return;
    }

    this.setState("reconnecting");
    this.reconnectAttempts++;
    const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts - 1), 30000);
    this.log?.info?.(
      `[GreatLove:${this.accountId}] Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`,
    );

    this.reconnectTimer = setTimeout(() => {
      this.connect();
    }, delay);
  }

  private setState(state: ConnectionState): void {
    if (this.state !== state) {
      this.state = state;
      this.onStateChange(state);
    }
  }

  getState(): ConnectionState {
    return this.state;
  }
}
