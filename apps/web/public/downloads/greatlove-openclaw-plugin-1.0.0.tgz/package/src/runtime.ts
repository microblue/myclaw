/**
 * GreatLove Runtime Context
 */

interface GreatLoveRuntime {
  channel: {
    session: {
      resolveStorePath: (store: any, opts: { agentId?: string }) => string;
    };
  };
  logger?: any;
}

let _runtime: GreatLoveRuntime | null = null;

export function setGreatLoveRuntime(runtime: GreatLoveRuntime): void {
  _runtime = runtime;
}

export function getGreatLoveRuntime(): GreatLoveRuntime {
  if (!_runtime) {
    throw new Error("GreatLove runtime not initialized.");
  }
  return _runtime;
}

export function getLogger(): any {
  return _runtime?.logger ?? console;
}
