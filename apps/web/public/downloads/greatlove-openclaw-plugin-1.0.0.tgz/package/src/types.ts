/**
 * GreatLove Channel Type Definitions
 */
import type { OpenClawConfig } from "openclaw/plugin-sdk/core";

export interface GreatLoveConfig {
  apiUrl?: string;
  pluginToken?: string;
  enabled?: boolean;
  name?: string;
  messageType?: "text" | "markdown";
  dmPolicy?: "open" | "allowlist" | "approval";
  allowFrom?: string[];
  groupPolicy?: "open" | "mention" | "allowlist";
  accounts?: Record<string, Partial<GreatLoveAccountConfig>>;
}

export interface GreatLoveAccountConfig {
  apiUrl?: string;
  pluginToken?: string;
  enabled?: boolean;
  name?: string;
  messageType?: "text" | "markdown";
  dmPolicy?: "open" | "allowlist" | "approval";
  allowFrom?: string[];
  groupPolicy?: "open" | "mention" | "allowlist";
}

export interface ResolvedAccount {
  accountId: string;
  config: GreatLoveConfig;
  enabled: boolean;
  configured: boolean;
  name: string | null;
}

/**
 * Edge Function /stream 推送的事件格式（SSE）
 */
export interface StreamEvent {
  type: "message" | "ping" | "error";
  data: InboundMessagePayload | { message: string };
}

/**
 * Edge Function 推送的入站消息体
 */
export interface InboundMessagePayload {
  messageId: string;
  senderId: string;
  senderName?: string;
  conversationId: string;
  content: string;
  type: "text" | "image" | "file" | "audio" | "video";
  mediaUrl?: string;
  isGroup: boolean;
  isMentioned?: boolean;
  timestamp: number;
}

export interface GreatLoveInboundMessage {
  messageId: string;
  senderId: string;
  senderName?: string;
  conversationId: string;
  type: "text" | "image" | "file" | "audio" | "video";
  text?: string;
  mediaUrl?: string;
  isGroup: boolean;
  isMentioned?: boolean;
  timestamp: number;
  raw?: unknown;
}

export type ConnectionState = "disconnected" | "connecting" | "connected" | "reconnecting" | "error";

export interface GreatLoveChannelPlugin {
  id: "greatlove";
  meta: any;
  configSchema: any;
  setup: any;
  setupWizard: any;
  capabilities: any;
  reload: any;
  config: any;
  security: any;
  groups: any;
  messaging: any;
  directory: any;
  actions: any;
  agentTools?: any;
  outbound: any;
  gateway: any;
}
