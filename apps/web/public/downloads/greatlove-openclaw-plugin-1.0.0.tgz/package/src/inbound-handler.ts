/**
 * GreatLove Inbound Handler
 * 处理从 Supabase Realtime 收到的入站消息
 */
import type { GreatLoveConfig, GreatLoveInboundMessage } from "./types";
import { markMessageProcessed } from "./send-service";
import { getLogger } from "./runtime";

export interface InboundContext {
  config: GreatLoveConfig;
  accountId: string;
  log?: any;
  onMessage: (event: GatewayMessageEvent) => Promise<void>;
}

export interface GatewayMessageEvent {
  channel: "greatlove";
  accountId: string;
  messageId: string;
  senderId: string;
  senderName?: string;
  conversationId: string;
  text: string;
  isGroup: boolean;
  isMentioned: boolean;
  timestamp: number;
  mediaUrl?: string;
  mediaType?: string;
  raw?: unknown;
}

/**
 * 处理入站消息，转换为 Gateway 事件格式并分发
 */
export async function handleInboundMessage(
  rawMessage: GreatLoveInboundMessage,
  context: InboundContext
): Promise<void> {
  const log = context.log ?? getLogger();

  log?.debug?.(`[GreatLove:${context.accountId}] Inbound from ${rawMessage.senderId}`);

  // 先标记已处理，防止多实例重复处理
  await markMessageProcessed(context.config, rawMessage.messageId, {
    accountId: context.accountId,
    log,
  });

  const event: GatewayMessageEvent = {
    channel: "greatlove",
    accountId: context.accountId,
    messageId: rawMessage.messageId,
    senderId: rawMessage.senderId,
    senderName: rawMessage.senderName,
    conversationId: rawMessage.conversationId,
    text: rawMessage.text ?? "",
    isGroup: rawMessage.isGroup,
    isMentioned: rawMessage.isMentioned ?? false,
    timestamp: rawMessage.timestamp,
    mediaUrl: rawMessage.mediaUrl,
    mediaType: rawMessage.type !== "text" ? rawMessage.type : undefined,
    raw: rawMessage.raw,
  };

  await context.onMessage(event);
}
