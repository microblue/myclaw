/**
 * GreatLove Send Service
 *
 * 通过 GreatLove Edge Function 发送消息，不直接操作 Supabase。
 * 服务端用 service_role 写库，插件只需 pluginToken。
 *
 * POST {apiUrl}/send
 *   Authorization: Bearer {pluginToken}
 *   Body: { to, content, type, mediaUrl? }
 */
import type { GreatLoveConfig } from "./types";
import { getLogger } from "./runtime";

export interface SendResult {
  ok: boolean;
  messageId?: string;
  error?: string;
  data?: unknown;
}

/**
 * 通用 HTTP 请求到 Edge Function
 */
async function callEdgeFunction(
  config: GreatLoveConfig,
  path: string,
  body: Record<string, unknown>,
  log?: any,
): Promise<{ ok: boolean; data?: any; error?: string }> {
  const { apiUrl, pluginToken } = config;

  if (!apiUrl || !pluginToken) {
    return { ok: false, error: "Missing apiUrl or pluginToken in config" };
  }

  const url = `${apiUrl.replace(/\/$/, "")}/${path.replace(/^\//, "")}`;

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${pluginToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    const data = (await response
      .json()
      .catch(() => ({}))) as { error?: string; message?: string; messageId?: string };

    if (!response.ok) {
      return {
        ok: false,
        error: data.error || data.message || `HTTP ${response.status}`,
      };
    }

    return { ok: true, data };
  } catch (err: any) {
    log?.error?.(`[GreatLove] callEdgeFunction error (${path}): ${err.message}`);
    return { ok: false, error: err.message };
  }
}

/**
 * 发送文本消息
 * POST {apiUrl}/send
 */
export async function sendTextMessage(
  config: GreatLoveConfig,
  to: string,
  text: string,
  options?: { accountId?: string; replyToMessageId?: string; log?: any },
): Promise<SendResult> {
  const log = options?.log ?? getLogger();

  const result = await callEdgeFunction(
    config,
    "send",
    {
      to,
      content: text,
      type: "text",
      replyToMessageId: options?.replyToMessageId,
    },
    log,
  );

  if (!result.ok) {
    return { ok: false, error: result.error };
  }

  return { ok: true, messageId: result.data?.messageId };
}

/**
 * 发送媒体消息
 * POST {apiUrl}/send-media
 *   先上传文件内容（base64），Edge Function 存到 Storage 再发
 */
export async function sendMediaMessage(
  config: GreatLoveConfig,
  to: string,
  mediaPath: string,
  mediaType: "image" | "file" | "audio" | "video",
  options?: { caption?: string; accountId?: string; log?: any },
): Promise<SendResult> {
  const log = options?.log ?? getLogger();

  try {
    const { readFile } = await import("node:fs/promises");
    const { basename } = await import("node:path");

    const fileBuffer = await readFile(mediaPath);
    const base64 = fileBuffer.toString("base64");
    const fileName = basename(mediaPath);

    const result = await callEdgeFunction(
      config,
      "send",
      {
        to,
        content: options?.caption || "",
        type: mediaType,
        media: {
          fileName,
          base64,
          mimeType: guessMime(mediaPath, mediaType),
        },
      },
      log,
    );

    if (!result.ok) {
      return { ok: false, error: result.error };
    }

    return { ok: true, messageId: result.data?.messageId };
  } catch (err: any) {
    return { ok: false, error: err.message };
  }
}

/**
 * 标记消息已处理
 * POST {apiUrl}/ack
 */
export async function markMessageProcessed(
  config: GreatLoveConfig,
  messageId: string,
  options?: { accountId?: string; log?: any },
): Promise<void> {
  await callEdgeFunction(config, "ack", { messageId }, options?.log);
}

function guessMime(filePath: string, mediaType: string): string {
  const ext = filePath.split(".").pop()?.toLowerCase();
  const map: Record<string, string> = {
    jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png",
    gif: "image/gif", webp: "image/webp",
    mp4: "video/mp4", mov: "video/quicktime",
    mp3: "audio/mpeg", ogg: "audio/ogg", wav: "audio/wav",
    pdf: "application/pdf", zip: "application/zip",
  };
  return (ext && map[ext]) || (mediaType === "image" ? "image/jpeg" : "application/octet-stream");
}
