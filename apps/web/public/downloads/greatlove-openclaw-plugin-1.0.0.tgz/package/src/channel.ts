/**
 * GreatLove Channel Plugin
 * 
 * 这是插件的核心文件，定义了 ChannelPlugin 接口的实现。
 * Gateway 通过这个对象来：
 * 1. 启动/停止连接 (gateway.start/stop)
 * 2. 发送消息 (outbound.sendText/sendMedia)
 * 3. 读取配置 (config.*)
 * 4. 处理安全策略 (security.*)
 */
import { randomUUID } from "node:crypto";
import { buildChannelConfigSchema, jsonResult, type OpenClawConfig } from "openclaw/plugin-sdk/core";
import type { ChannelMessageActionAdapter } from "openclaw/plugin-sdk/channel-contract";
import { readStringParam } from "openclaw/plugin-sdk/param-readers";
import { extractToolSend } from "openclaw/plugin-sdk/tool-send";

import { GreatLoveConfigSchema } from "./config-schema";
import { 
  getConfig, 
  isConfigured, 
  mergeAccountWithDefaults, 
  listAccountIds,
  stripTargetPrefix,
  normalizeTarget,
} from "./config";
import { ConnectionManager } from "./connection-manager";
import { handleInboundMessage, type InboundContext } from "./inbound-handler";
import { sendTextMessage, sendMediaMessage } from "./send-service";
import { getLogger, getGreatLoveRuntime } from "./runtime";
import { greatloveSetupAdapter, greatloveSetupWizard } from "./setup-wizard";
import { handleLoginWithQrStart, handleLoginWithQrWait } from "./qr-login";
import { createGreatLovePairTool } from "./agent-tools";
import type { 
  GreatLoveChannelPlugin, 
  ResolvedAccount, 
  GreatLoveInboundMessage,
  ConnectionState,
} from "./types";

// ============================================================================
// 连接管理器实例（按账号）
// ============================================================================
const connectionManagers = new Map<string, ConnectionManager>();

// ============================================================================
// Message Actions (工具调用处理)
// ============================================================================
const greatloveMessageActions: ChannelMessageActionAdapter = {
  /**
   * 描述消息工具的能力
   */
  describeMessageTool: ({ cfg }) => {
    const config = getConfig(cfg);
    const configured = Boolean(config.apiUrl && config.pluginToken);
    if (!configured) {
      return { actions: [], capabilities: [], schema: null };
    }
    return {
      actions: ["send"] as const,
      capabilities: [],
      schema: null,
    };
  },

  /**
   * 支持哪些动作
   */
  supportsAction: ({ action }) => action === "send",

  /**
   * 从参数中提取发送信息
   */
  extractToolSend: ({ args }) => extractToolSend(args, "sendMessage"),

  /**
   * 处理发送动作
   */
  handleAction: async ({ action, params, cfg, accountId, dryRun }) => {
    if (action !== "send") {
      throw new Error(`Action ${action} is not supported for greatlove channel.`);
    }

    const to = readStringParam(params, "to", { required: true });
    const message = readStringParam(params, "message", { required: true });
    const mediaUrl = readStringParam(params, "mediaUrl");

    const target = normalizeTarget(to);

    if (dryRun) {
      return jsonResult({ ok: true, dryRun: true, to: target });
    }

    const log = getLogger();
    const config = getConfig(cfg, accountId ?? undefined);

    if (mediaUrl) {
      const result = await sendMediaMessage(config, target, mediaUrl, "file", {
        caption: message,
        accountId: accountId ?? undefined,
        log,
      });
      return jsonResult({
        ok: result.ok,
        to: target,
        messageId: result.messageId ?? null,
        error: result.error,
      });
    }

    const result = await sendTextMessage(config, target, message, {
      accountId: accountId ?? undefined,
      log,
    });

    return jsonResult({
      ok: result.ok,
      to: target,
      messageId: result.messageId ?? null,
      error: result.error,
    });
  },
};

// ============================================================================
// 核心 Channel Plugin 定义
// ============================================================================
export const greatlovePlugin: GreatLoveChannelPlugin = {
  /**
   * 插件 ID（必须与 openclaw.plugin.json 中的 id 一致）
   */
  id: "greatlove",

  /**
   * 元数据（用于 UI 显示）
   */
  meta: {
    id: "greatlove",
    label: "GreatLove",
    selectionLabel: "GreatLove APP",
    // Points at the install + pairing guide. Binding happens via pasting a prompt
    // into Claude Code in this host's terminal — see docs/INSTALL_PROMPT.md.
    docsPath: "https://github.com/microblue/claw-greatlove-plugin#安装--绑定",
    docsLabel: "安装 / 绑定说明",
    blurb: "GreatLove APP messaging integration — 把 INSTALL_PROMPT.md 里的提示贴给 Claude Code 就能自动安装+绑定",
    aliases: ["gl", "love"],
    // Without this, dashboard /channels view filters us out
    exposure: { configured: true, setup: true, docs: true },
    detailLabel: "GreatLove APP",
  } as any,

  /**
   * 配置 Schema（用于验证用户配置）
   */
  configSchema: buildChannelConfigSchema(GreatLoveConfigSchema),

  /**
   * 设置向导（CLI 交互式配置 + dashboard）
   * prepare() 里跑 6 位数字配对流程：显示验证码 → 轮询 → 自动写入 apiUrl + pluginToken
   */
  setup: greatloveSetupAdapter,
  setupWizard: greatloveSetupWizard,

  /**
   * 通道能力声明
   */
  capabilities: {
    chatTypes: ["direct", "group"] as Array<"direct" | "group">,
    reactions: false,      // 是否支持表情回应
    threads: false,        // 是否支持话题/线程
    media: true,           // 是否支持媒体消息
    nativeCommands: false, // 是否支持原生斜杠命令
    blockStreaming: false, // 是否阻塞流式输出
  },

  /**
   * 配置热重载
   */
  reload: { 
    configPrefixes: ["channels.greatlove"] 
  },

  /**
   * 配置管理接口
   */
  config: {
    /**
     * 列出所有配置的账号 ID
     */
    listAccountIds: (cfg: OpenClawConfig): string[] => {
      return listAccountIds(cfg);
    },

    /**
     * 解析账号配置
     */
    resolveAccount: (cfg: OpenClawConfig, accountId?: string | null): ResolvedAccount => {
      const config = getConfig(cfg);
      const id = accountId || "default";
      const account = config.accounts?.[id];
      const resolvedConfig = account ? mergeAccountWithDefaults(config, account) : config;
      const configured = Boolean(resolvedConfig.apiUrl && resolvedConfig.pluginToken);
      
      return {
        accountId: id,
        config: resolvedConfig,
        enabled: resolvedConfig.enabled !== false,
        configured,
        name: resolvedConfig.name || null,
      };
    },

    /**
     * 默认账号 ID
     */
    defaultAccountId: (): string => "default",

    /**
     * 检查账号是否已配置
     */
    isConfigured: (account: ResolvedAccount): boolean => {
      return Boolean(account.config?.apiUrl && account.config?.pluginToken);
    },

    /**
     * 描述账号（用于 UI 显示）
     */
    describeAccount: (account: ResolvedAccount) => ({
      accountId: account.accountId,
      name: account.config?.name || "GreatLove",
      enabled: account.enabled,
      configured: Boolean(account.config?.apiUrl && account.config?.pluginToken),
    }),
  },

  /**
   * 安全策略
   */
  security: {
    resolveDmPolicy: ({ account }: any) => ({
      policy: account.config?.dmPolicy || "open",
      allowFrom: account.config?.allowFrom || [],
      policyPath: "channels.greatlove.dmPolicy",
      allowFromPath: "channels.greatlove.allowFrom",
      approveHint: "使用 /allow greatlove:<userId> 批准用户",
      normalizeEntry: (raw: string) => raw.replace(/^(greatlove|gl|love):/i, ""),
    }),
  },

  /**
   * 群组相关
   */
  groups: {
    resolveRequireMention: ({ cfg, groupId }: any): boolean => {
      const config = getConfig(cfg);
      return config.groupPolicy !== "open";
    },
    resolveGroupIntroHint: ({ groupId }: any): string | undefined => {
      return `GreatLove Group ID: ${groupId}`;
    },
  },

  /**
   * 消息相关
   */
  messaging: {
    normalizeTarget: (raw: string) => raw ? normalizeTarget(raw) : undefined,
    targetResolver: {
      looksLikeId: (raw: string): boolean => /^[a-zA-Z0-9_-]+$/.test(raw),
      hint: "<userId|groupId>",
    },
  },

  /**
   * 目录服务（用户/群组列表）
   */
  directory: {
    self: async () => null,
    listGroups: async () => ({ groups: [] }),
    listGroupsLive: async () => ({ groups: [] }),
    listPeers: async () => ({ peers: [] }),
    listPeersLive: async () => ({ peers: [] }),
  },

  /**
   * 消息动作处理器
   */
  actions: greatloveMessageActions,

  /**
   * Agent tools — exposed to the OpenClaw LLM agent. When the user asks
   * "绑定 GreatLove" in OpenClaw chat, the agent invokes `greatlove_pair`.
   */
  agentTools: () => [createGreatLovePairTool()],

  /**
   * 出站消息接口
   */
  outbound: {
    deliveryMode: "direct" as const,

    /**
     * 解析目标
     */
    resolveTarget: ({ to }: any) => {
      const trimmed = to?.trim();
      if (!trimmed) {
        return {
          ok: false as const,
          error: new Error("GreatLove message requires --to <target>"),
        };
      }
      return { ok: true as const, to: normalizeTarget(trimmed) };
    },

    /**
     * 发送文本消息
     */
    sendText: async ({ cfg, to, text, accountId, log }: any) => {
      const config = getConfig(cfg, accountId);
      
      const result = await sendTextMessage(config, to, text, { log, accountId });
      
      if (!result.ok) {
        throw new Error(result.error || "sendText failed");
      }

      return {
        channel: "greatlove",
        messageId: result.messageId || randomUUID(),
        meta: result.data ? { data: result.data } : undefined,
      };
    },

    /**
     * 发送媒体消息
     */
    sendMedia: async ({ cfg, to, mediaPath, mediaType, accountId, log }: any) => {
      const config = getConfig(cfg, accountId);
      
      const result = await sendMediaMessage(config, to, mediaPath, mediaType, { log, accountId });
      
      if (!result.ok) {
        throw new Error(result.error || "sendMedia failed");
      }

      return {
        channel: "greatlove",
        messageId: result.messageId || randomUUID(),
      };
    },
  },

  /**
   * Gateway 生命周期管理
   * 这是连接 GreatLove 服务的核心
   */
  gateway: {
    /**
     * OpenClaw 调此方法启动每个已配置的 account 的订阅。
     * 注意方法名必须是 startAccount（不是 start），OpenClaw 路由只查这个名字。
     */
    startAccount: async (ctx: any) => {
      const { cfg, accountId, log, channelRuntime, setStatus } = ctx;
      const id = accountId || "default";
      const config = getConfig(cfg, accountId);

      log?.info?.(`[GreatLove:${id}] startAccount invoked`);
      setStatus?.({
        accountId: id,
        running: true,
        connected: false,
        configured: Boolean(config.apiUrl && config.pluginToken),
        enabled: config.enabled !== false,
        lastStartAt: Date.now(),
        healthState: "starting",
        statusState: "starting",
      });

      if (!config.apiUrl || !config.pluginToken) {
        log?.warn?.(`[GreatLove:${id}] missing apiUrl or pluginToken, skip`);
        setStatus?.({
          accountId: id,
          running: false,
          connected: false,
          configured: false,
          enabled: config.enabled !== false,
          lastError: "missing apiUrl or pluginToken",
          healthState: "unconfigured",
          statusState: "unconfigured",
        });
        return;
      }

      const manager = new ConnectionManager({
        config,
        accountId: id,
        log,
        onMessage: async (msg: GreatLoveInboundMessage) => {
          setStatus?.({
            accountId: id,
            lastInboundAt: Date.now(),
            lastEventAt: Date.now(),
          });
          const context: InboundContext = {
            config,
            accountId: id,
            log,
            // Forward into OpenClaw's reply pipeline if available; otherwise log.
            onMessage: async (event: any) => {
              if (channelRuntime?.reply?.dispatchReplyWithBufferedBlockDispatcher) {
                try {
                  await channelRuntime.reply.dispatchReplyWithBufferedBlockDispatcher({
                    ctx: {
                      // MsgContext fields (OpenClaw agent reads these)
                      Body: event.text ?? "",
                      RawBody: event.text ?? "",
                      BodyForAgent: event.text ?? "",
                      BodyForCommands: event.text ?? "",
                      From: event.senderId,
                      To: event.conversationId,
                      SessionKey: `greatlove:${id}:${event.conversationId}`,
                      AccountId: id,
                      MessageSid: event.messageId,
                      ChatType: event.isGroup ? "group" : "direct",
                      ConversationLabel: event.senderName || event.senderId,
                      // Keep original event data too
                      channel: "greatlove",
                      accountId: id,
                      ...event,
                    },
                    cfg,
                    dispatcherOptions: {
                      deliver: async (payload: any) => {
                        const text =
                          typeof payload?.text === "string"
                            ? payload.text
                            : typeof payload?.body === "string"
                              ? payload.body
                              : typeof payload?.content === "string"
                                ? payload.content
                                : String(payload?.message ?? payload ?? "");
                        if (!text) return;
                        await sendTextMessage(config, event.conversationId, text, {
                          accountId: id,
                          replyToMessageId: event.messageId,
                          log,
                        });
                      },
                    },
                  });
                } catch (err) {
                  log?.error?.(`[GreatLove:${id}] dispatch failed: ${(err as Error).message}`);
                }
              } else {
                log?.info?.(`[GreatLove:${id}] inbound: ${event.text?.slice(0, 80)}`);
              }
            },
          };
          await handleInboundMessage(msg, context);
        },
        onStateChange: (state: ConnectionState) => {
          log?.info?.(`[GreatLove:${id}] connection state: ${state}`);
          const connected = state === "connected";
          setStatus?.({
            accountId: id,
            running: true,
            connected,
            configured: true,
            enabled: config.enabled !== false,
            healthState: state === "connected" ? "healthy" : state,
            statusState: state,
            lastConnectedAt: connected ? Date.now() : undefined,
          });
        },
      });

      await manager.start();
      connectionManagers.set(id, manager);
      log?.info?.(`[GreatLove:${id}] subscribed to Supabase Realtime`);

      // Keep the task alive until OpenClaw cancels us via abortSignal.
      // Otherwise gateway thinks startAccount finished = channel stopped = auto-restart loop.
      const abortSignal: AbortSignal | undefined = ctx.abortSignal;
      if (abortSignal) {
        await new Promise<void>((resolve) => {
          if (abortSignal.aborted) return resolve();
          abortSignal.addEventListener("abort", () => resolve(), { once: true });
        });
        log?.info?.(`[GreatLove:${id}] abortSignal fired, stopping`);
        await manager.stop();
        connectionManagers.delete(id);
      }
    },

    /**
     * Dashboard "Link account" button hook — shows QR + 6-digit code to the operator.
     * This is what makes greatlove appear with a clickable Link UI in the dashboard.
     */
    loginWithQrStart: handleLoginWithQrStart,
    loginWithQrWait: handleLoginWithQrWait,

    stopAccount: async (ctx: any) => {
      const { accountId, log, setStatus } = ctx;
      const id = accountId || "default";
      const manager = connectionManagers.get(id);
      if (manager) {
        await manager.stop();
        connectionManagers.delete(id);
        log?.info?.(`[GreatLove:${id}] stopAccount done`);
      }
      setStatus?.({
        accountId: id,
        running: false,
        connected: false,
        lastStopAt: Date.now(),
        healthState: "stopped",
        statusState: "stopped",
      });
    },
  },
};
