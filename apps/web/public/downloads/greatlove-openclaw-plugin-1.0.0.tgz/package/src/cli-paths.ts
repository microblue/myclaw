// Path helpers. Isolated from files that do network I/O.
import path from "node:path";

export function resolveConfigPathFromHost(): string {
  return (
    process.env.OPENCLAW_CONFIG_PATH ||
    path.join(process.env.HOME || "", ".openclaw", "openclaw.json")
  );
}
