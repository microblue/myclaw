/**
 * Dashboard-driven pairing: implements gateway.loginWithQrStart + loginWithQrWait.
 *
 * Dashboard shows a "Link account" button for channels that expose these methods.
 * Clicking the button triggers this flow:
 *   1. loginWithQrStart → returns {qrDataUrl, message} → dashboard renders QR + text
 *   2. User opens GreatLove APP, scans QR or types the 6-digit code
 *   3. Dashboard polls loginWithQrWait → returns {connected:true} once claimed
 *   4. We write apiUrl + pluginToken into the config file before returning
 */
import fs from "node:fs";
import QRCode from "qrcode";
import { resolveConfigPathFromHost } from "./cli-paths";

const DEFAULT_API_URL = "https://edaygteqqoqezshlxmmx.supabase.co/functions/v1/greatlove-plugin";

// Per-accountId transient state during a pairing session
interface PairingState {
  code: string;
  watcherToken: string;
  apiUrl: string;
  startedAt: number;
  expiresAt: number;
  pollIntervalMs: number;
}
const pairingSessions = new Map<string, PairingState>();

interface StartResult {
  qrDataUrl?: string;
  message: string;
  connected?: boolean;
}

interface WaitResult {
  connected: boolean;
  message: string;
}

async function postJson(url: string, body?: unknown): Promise<{ ok: boolean; data: any }> {
  const r = await fetch(url, {
    method: "POST",
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await r.json().catch(() => ({}));
  return { ok: r.ok, data };
}

function readConfig(p: string): Record<string, any> {
  try {
    return JSON.parse(fs.readFileSync(p, "utf8"));
  } catch {
    return {};
  }
}

function writeConfigFile(p: string, cfg: Record<string, any>): void {
  try {
    fs.copyFileSync(p, `${p}.bak.${Date.now()}`);
  } catch {
    // first write, no backup needed
  }
  fs.writeFileSync(p, JSON.stringify(cfg, null, 2) + "\n", "utf8");
}

function persistPluginToken(accountId: string, apiUrl: string, pluginToken: string): void {
  const cfgPath = resolveConfigPathFromHost();
  const cfg = readConfig(cfgPath);
  cfg.channels = cfg.channels || {};
  const existing = cfg.channels.greatlove || {};

  if (!accountId || accountId === "default") {
    cfg.channels.greatlove = {
      ...existing,
      apiUrl,
      pluginToken,
      enabled: true,
    };
  } else {
    const accounts = { ...(existing.accounts || {}) };
    accounts[accountId] = {
      ...(accounts[accountId] || {}),
      apiUrl,
      pluginToken,
      enabled: true,
    };
    cfg.channels.greatlove = { ...existing, accounts };
  }

  writeConfigFile(cfgPath, cfg);
}

async function buildQr(code: string, apiUrl: string): Promise<string | undefined> {
  // QR encodes a deep link that APPs can route. If APP isn't installed,
  // fallback is to just type the numeric code (also shown as text).
  const link = `greatlove://pair?code=${code}&api=${encodeURIComponent(apiUrl)}`;
  try {
    return await QRCode.toDataURL(link, {
      errorCorrectionLevel: "M",
      margin: 1,
      width: 280,
    });
  } catch {
    return undefined;
  }
}

function prettyCode(code: string): string {
  return code.length === 6 ? `${code.slice(0, 3)} ${code.slice(3)}` : code;
}

export async function handleLoginWithQrStart(params: {
  accountId?: string;
  force?: boolean;
  timeoutMs?: number;
}): Promise<StartResult> {
  const accountId = params.accountId || "default";

  // Reuse a still-valid session if not forced
  const existing = pairingSessions.get(accountId);
  if (!params.force && existing && Date.now() < existing.expiresAt) {
    const qr = await buildQr(existing.code, existing.apiUrl);
    return {
      qrDataUrl: qr,
      message: `在 GreatLove APP 中输入验证码：${prettyCode(existing.code)}（${Math.ceil((existing.expiresAt - Date.now()) / 1000)} 秒内有效）`,
      connected: false,
    };
  }

  const apiUrl = DEFAULT_API_URL;
  const { ok, data } = await postJson(`${apiUrl}/pair/start`);
  if (!ok || !data?.code || !data?.watcherToken) {
    return {
      message: `启动配对失败：${data?.error || "server error"}`,
      connected: false,
    };
  }

  const ttlSec = data.expiresInSeconds ?? 300;
  const state: PairingState = {
    code: data.code,
    watcherToken: data.watcherToken,
    apiUrl,
    startedAt: Date.now(),
    expiresAt: Date.now() + ttlSec * 1000,
    pollIntervalMs: (data.pollIntervalSeconds ?? 2) * 1000,
  };
  pairingSessions.set(accountId, state);

  const qr = await buildQr(state.code, apiUrl);
  return {
    qrDataUrl: qr,
    message: `请在 GreatLove APP 中输入验证码：${prettyCode(state.code)}（或扫描二维码），${ttlSec} 秒内有效`,
    connected: false,
  };
}

export async function handleLoginWithQrWait(params: {
  accountId?: string;
  timeoutMs?: number;
}): Promise<WaitResult> {
  const accountId = params.accountId || "default";
  const state = pairingSessions.get(accountId);
  if (!state) {
    return {
      connected: false,
      message: "没有正在进行的配对。请先点「Link」生成验证码。",
    };
  }

  const deadline = Math.min(state.expiresAt, Date.now() + (params.timeoutMs ?? 300_000));
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, state.pollIntervalMs));
    try {
      const { ok, data } = await postJson(`${state.apiUrl}/pair/status`, {
        code: state.code,
        watcherToken: state.watcherToken,
      });
      if (!ok) continue; // transient
      if (data.status === "claimed" && data.pluginToken) {
        persistPluginToken(accountId, state.apiUrl, data.pluginToken);
        pairingSessions.delete(accountId);
        return {
          connected: true,
          message: `✅ 已绑定 ${data.userEmail || data.userId || "account"}。配置已自动写入，请重启 gateway。`,
        };
      }
      if (data.status === "expired") {
        pairingSessions.delete(accountId);
        return { connected: false, message: "验证码已过期，请重新点 Link。" };
      }
      // pending → keep polling
    } catch {
      // network hiccup → keep polling
    }
  }

  return { connected: false, message: "等待超时。请重新点 Link。" };
}
