/**
 * GreatLove Plugin - Configuration Schema
 *
 * 用户只需填两个字段：
 *   apiUrl      - GreatLove Edge Function 基础地址
 *   pluginToken - 从 GreatLove APP 生成的插件 Token（可吊销）
 */
import { z } from "zod";

export const GreatLoveAccountSchema = z.object({
  /** GreatLove Edge Function 基础 URL
   *  例: https://xxxx.supabase.co/functions/v1/greatlove-plugin
   *  或你自己域名: https://api.greatlove.club/plugin
   */
  apiUrl: z.string().url().optional(),
  /** 从 GreatLove APP 生成的插件 Token（类似 Telegram botToken）
   *  GreatLove 后端颁发，可随时吊销，与 Supabase 凭据完全隔离
   */
  pluginToken: z.string().optional(),
  /** 是否启用 */
  enabled: z.boolean().default(true),
  /** 账号名称 */
  name: z.string().optional(),
  /** 消息类型 */
  messageType: z.enum(["text", "markdown"]).default("text"),
  /** DM 策略 */
  dmPolicy: z.enum(["open", "allowlist", "approval"]).default("open"),
  /** 允许列表 */
  allowFrom: z.array(z.string()).default([]),
  /** 群组策略 */
  groupPolicy: z.enum(["open", "mention", "allowlist"]).default("mention"),
});

export const GreatLoveConfigSchema = z.object({
  apiUrl: z.string().url().optional(),
  pluginToken: z.string().optional(),
  enabled: z.boolean().default(true),
  name: z.string().optional(),
  messageType: z.enum(["text", "markdown"]).default("text"),
  dmPolicy: z.enum(["open", "allowlist", "approval"]).default("open"),
  allowFrom: z.array(z.string()).default([]),
  groupPolicy: z.enum(["open", "mention", "allowlist"]).default("mention"),
  accounts: z.record(z.string(), GreatLoveAccountSchema.partial()).optional(),
});

export type GreatLoveConfigInput = z.input<typeof GreatLoveConfigSchema>;
export type GreatLoveConfigOutput = z.output<typeof GreatLoveConfigSchema>;
