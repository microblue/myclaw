/**
 * GreatLove CLI — registers the `openclaw greatlove pair` subcommand.
 *
 * This is registered via api.registerCli() which runs at CLI parse time,
 * so the command is available even when the channel has no config yet
 * (solves the chicken-and-egg of "plugin only activates when configured").
 *
 * Flow:
 *   1. POST /pair/start → 6-digit code + watcherToken
 *   2. Print code in terminal with a nice box
 *   3. Poll /pair/status for up to 5 min
 *   4. On claimed, write channels.greatlove.{apiUrl, pluginToken} to config
 *   5. Prompt user to restart gateway
 */
import fs from "node:fs";
import { resolveConfigPathFromHost } from "./cli-paths";

const DEFAULT_API_URL = "https://edaygteqqoqezshlxmmx.supabase.co/functions/v1/greatlove-plugin";

interface PairStartResp {
  code?: string;
  watcherToken?: string;
  expiresInSeconds?: number;
  pollIntervalSeconds?: number;
}

interface PairStatusResp {
  status?: string;
  pluginToken?: string;
  userEmail?: string;
  userId?: string;
  error?: string;
}

const resolveConfigPath = resolveConfigPathFromHost;

function readConfig(p: string): Record<string, any> {
  try {
    return JSON.parse(fs.readFileSync(p, "utf8"));
  } catch {
    return {};
  }
}

function writeConfig(p: string, cfg: Record<string, any>): void {
  const backup = `${p}.bak.${Date.now()}`;
  try {
    fs.copyFileSync(p, backup);
  } catch {
    // no existing file to back up — fine for first time
  }
  fs.writeFileSync(p, JSON.stringify(cfg, null, 2) + "\n", "utf8");
}

export function registerPairCli(ctx: {
  program: any;
  logger?: any;
}): void {
  const { program } = ctx;

  // Top-level: openclaw greatlove ...
  const greatlove = program
    .command("greatlove")
    .description("GreatLove APP channel helpers (pair, info)");

  greatlove
    .command("pair")
    .description("Pair this OpenClaw with your GreatLove APP account via 6-digit code")
    .option(
      "--api-url <url>",
      `GreatLove Edge Function base URL (default: ${DEFAULT_API_URL})`,
    )
    .option("--no-write-config", "Only print the resulting pluginToken, don't modify config")
    .option("--timeout-seconds <n>", "Pairing timeout", "300")
    .action(async (opts: { apiUrl?: string; writeConfig: boolean; timeoutSeconds: string }) => {
      const apiUrl = (opts.apiUrl || DEFAULT_API_URL).replace(/\/$/, "");
      const timeoutSec = Math.max(60, parseInt(opts.timeoutSeconds, 10) || 300);

      // 1. start
      let start: PairStartResp;
      try {
        const r = await fetch(`${apiUrl}/pair/start`, { method: "POST" });
        if (!r.ok) {
          console.error(`ERROR: /pair/start returned ${r.status}`);
          process.exit(1);
        }
        start = (await r.json()) as PairStartResp;
      } catch (err) {
        console.error(`ERROR: couldn't reach ${apiUrl}/pair/start: ${(err as Error).message}`);
        process.exit(1);
        return;
      }

      const code = start.code;
      const watcherToken = start.watcherToken;
      if (!code || !watcherToken) {
        console.error("ERROR: server didn't return code/watcherToken");
        process.exit(1);
        return;
      }

      const pretty = `${code.slice(0, 3)} ${code.slice(3)}`;
      const ttl = start.expiresInSeconds ?? 300;
      const intervalMs = (start.pollIntervalSeconds ?? 2) * 1000;

      // 2. show code
      console.log("");
      console.log("╔══════════════════════════════════════════════╗");
      console.log("║                                              ║");
      console.log("║   打开 GreatLove APP，输入以下验证码：       ║");
      console.log("║                                              ║");
      console.log(`║                ${pretty}                      ║`);
      console.log("║                                              ║");
      console.log(`║           ${ttl} 秒内有效                     ║`);
      console.log("║                                              ║");
      console.log("╚══════════════════════════════════════════════╝");
      console.log("");
      console.log("没有 APP？用浏览器： http://localhost:5500/pair.html");
      console.log("");
      process.stdout.write("等待确认");

      // 3. poll
      const deadline = Date.now() + Math.min(timeoutSec, ttl) * 1000;
      let final: PairStatusResp | null = null;
      while (Date.now() < deadline) {
        await new Promise((r) => setTimeout(r, intervalMs));
        process.stdout.write(".");
        try {
          const r = await fetch(`${apiUrl}/pair/status`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code, watcherToken }),
          });
          const data = (await r.json().catch(() => ({}))) as PairStatusResp;
          if (data.status === "claimed") {
            final = data;
            break;
          }
          if (data.status === "expired") {
            console.log("\n");
            console.error("❌ 验证码已过期，重试即可");
            process.exit(1);
            return;
          }
        } catch {
          // network hiccup — retry
        }
      }
      console.log("");

      if (!final || !final.pluginToken) {
        console.error("❌ 超时未确认");
        process.exit(1);
        return;
      }

      const who = final.userEmail || final.userId || "(unknown)";
      console.log(`✅ 已绑定：${who}`);
      console.log("");

      if (!opts.writeConfig) {
        // --no-write-config: just print
        console.log("配置片段（手动粘贴到 ~/.openclaw/openclaw.json）：");
        console.log("");
        console.log("  \"channels\": {");
        console.log("    \"greatlove\": {");
        console.log(`      \"apiUrl\": \"${apiUrl}\",`);
        console.log(`      \"pluginToken\": \"${final.pluginToken}\",`);
        console.log("      \"enabled\": true");
        console.log("    }");
        console.log("  }");
        return;
      }

      // 4. write to config
      const cfgPath = resolveConfigPath();
      if (!fs.existsSync(cfgPath)) {
        console.error(`WARN: ${cfgPath} 不存在，跳过写入`);
        console.log("");
        console.log(`手动写入:`);
        console.log(`  apiUrl      = ${apiUrl}`);
        console.log(`  pluginToken = ${final.pluginToken}`);
        return;
      }
      const cfg = readConfig(cfgPath);
      cfg.channels = cfg.channels || {};
      cfg.channels.greatlove = {
        ...(cfg.channels.greatlove || {}),
        apiUrl,
        pluginToken: final.pluginToken,
        enabled: true,
      };
      writeConfig(cfgPath, cfg);
      console.log(`✍️  已写入 ${cfgPath}`);
      console.log("");

      // 5. restart hint
      console.log("🔄 重启 gateway 让新配置生效：");
      console.log("     systemctl --user restart openclaw-gateway");
      console.log("   或");
      console.log("     openclaw gateway restart");
    });

  greatlove
    .command("info")
    .description("Show GreatLove channel config + connection state")
    .action(() => {
      const cfgPath = resolveConfigPath();
      const cfg = readConfig(cfgPath);
      const gl = cfg.channels?.greatlove ?? {};
      console.log("GreatLove channel config:");
      console.log(`  config file:  ${cfgPath}`);
      console.log(`  enabled:      ${gl.enabled ?? false}`);
      console.log(`  apiUrl:       ${gl.apiUrl ?? "(not set)"}`);
      console.log(`  pluginToken:  ${gl.pluginToken ? gl.pluginToken.slice(0, 10) + "…(redacted)" : "(not set)"}`);
      console.log(`  dmPolicy:     ${gl.dmPolicy ?? "open"}`);
      const accounts = gl.accounts ? Object.keys(gl.accounts) : [];
      if (accounts.length) {
        console.log(`  accounts:     ${accounts.join(", ")}`);
      }
    });
}
