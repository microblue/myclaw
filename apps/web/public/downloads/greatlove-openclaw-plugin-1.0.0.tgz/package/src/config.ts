/**
 * GreatLove Configuration Resolver
 */
import type { OpenClawConfig } from "openclaw/plugin-sdk/core";
import type { GreatLoveConfig, GreatLoveAccountConfig } from "./types";

export function getConfig(cfg: OpenClawConfig, accountId?: string): GreatLoveConfig {
  const raw = (cfg as any)?.channels?.greatlove ?? {};
  if (accountId && accountId !== "default" && raw.accounts?.[accountId]) {
    return mergeAccountWithDefaults(raw, raw.accounts[accountId]);
  }
  return raw;
}

export function isConfigured(cfg: OpenClawConfig): boolean {
  const config = getConfig(cfg);
  if (config.apiUrl && config.pluginToken) return true;
  if (config.accounts) {
    return Object.values(config.accounts).some(
      (acc) => acc?.apiUrl && acc?.pluginToken
    );
  }
  return false;
}

export function mergeAccountWithDefaults(
  defaults: GreatLoveConfig,
  account: Partial<GreatLoveAccountConfig>
): GreatLoveConfig {
  return {
    apiUrl: account.apiUrl ?? defaults.apiUrl,
    pluginToken: account.pluginToken ?? defaults.pluginToken,
    enabled: account.enabled ?? defaults.enabled ?? true,
    name: account.name ?? defaults.name,
    messageType: account.messageType ?? defaults.messageType ?? "text",
    dmPolicy: account.dmPolicy ?? defaults.dmPolicy ?? "open",
    allowFrom: account.allowFrom ?? defaults.allowFrom ?? [],
    groupPolicy: account.groupPolicy ?? defaults.groupPolicy ?? "mention",
  };
}

export function listAccountIds(cfg: OpenClawConfig): string[] {
  const config = getConfig(cfg);
  if (config.accounts && Object.keys(config.accounts).length > 0) {
    return Object.keys(config.accounts);
  }
  // 始终返回 default —— 插件即使未配置也加载，以便 gateway 方法可用于 pairing
  return ["default"];
}

export function stripTargetPrefix(target: string): { targetId: string; prefix?: string } {
  const prefixMatch = target.match(/^(greatlove|gl|love):/i);
  if (prefixMatch) {
    return { targetId: target.slice(prefixMatch[0].length), prefix: prefixMatch[1].toLowerCase() };
  }
  return { targetId: target };
}

export function normalizeTarget(raw: string): string {
  return stripTargetPrefix(raw.trim()).targetId;
}
