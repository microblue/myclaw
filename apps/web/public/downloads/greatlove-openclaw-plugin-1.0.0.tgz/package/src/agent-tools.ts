/**
 * Agent tool exposed to the OpenClaw chat agent. When the user asks "bind GreatLove"
 * (or similar) in the OpenClaw dashboard chat, the LLM picks up this tool and runs
 * the pair flow end-to-end without the user touching a terminal, browser, or
 * APP-side website.
 *
 * Flow via tool calls:
 *   1. agent calls greatlove_pair(action="start")
 *        → POST /pair/start, returns 6-digit code + watcherToken
 *        → tool result tells agent to display code and instruct user to open APP
 *
 *   2. user types code in GreatLove APP / confirms
 *
 *   3. agent calls greatlove_pair(action="wait", code=..., watcherToken=...)
 *        → polls /pair/status until claimed (or expired / timeout)
 *        → on claimed, writes apiUrl + pluginToken into openclaw.json
 *        → returns success to agent; agent replies "已绑定" to user
 *
 * Why an agent tool instead of shell commands:
 *   - OpenClaw LLM agent typically has no bash/shell tool
 *   - Agent tools are the SUPPORTED way plugins extend agent capabilities
 *   - Same mechanism WhatsApp uses for QR login (`whatsapp_login` tool)
 */
import { Type } from "@sinclair/typebox";
import { handleLoginWithQrStart, handleLoginWithQrWait } from "./qr-login";

function textResult(text: string, details: Record<string, unknown> = {}) {
  return {
    content: [{ type: "text", text }],
    details,
  };
}

/**
 * Factory returns the tool object. OpenClaw may call this eagerly or per-turn.
 * Kept stateless; per-account state lives in qr-login.ts.
 */
export function createGreatLovePairTool(): any {
  return {
    label: "GreatLove 绑定",
    name: "greatlove_pair",
    // ownerOnly: only the OpenClaw operator (the user talking to the agent) can
    // invoke this — not peers in groups.
    ownerOnly: true,
    description:
      "Bind this OpenClaw to a GreatLove APP user account via a 6-digit code. " +
      "Use action='start' to request a new code (first step). Show the code prominently to the user and ask them to open GreatLove APP → AI 助手 → 绑定 → enter the code. " +
      "Then use action='wait' to block until the user confirms in APP (or until timeout). " +
      "On success, the plugin config is written automatically and the gateway restarts. " +
      "Don't ask the user for apiUrl or tokens — this tool handles everything.",
    parameters: Type.Object({
      action: Type.Union([Type.Literal("start"), Type.Literal("wait")], {
        description: "'start' to request a new 6-digit code, 'wait' to poll for APP confirmation.",
      }),
      accountId: Type.Optional(
        Type.String({
          description: "OpenClaw account id (default: 'default'). Only needed for multi-account setups.",
        }),
      ),
      timeoutSeconds: Type.Optional(
        Type.Number({
          description: "Max seconds to wait on action='wait' (default 300).",
        }),
      ),
    }),
    execute: async (_toolCallId: string, params: any) => {
      const accountId = typeof params?.accountId === "string" ? params.accountId : "default";

      if (params?.action === "wait") {
        const timeoutMs =
          typeof params?.timeoutSeconds === "number"
            ? params.timeoutSeconds * 1000
            : 300_000;
        const res = await handleLoginWithQrWait({ accountId, timeoutMs });
        return textResult(res.message, { connected: res.connected });
      }

      // action === "start"
      const res = await handleLoginWithQrStart({ accountId });
      const lines = [
        "✅ 已请求配对验证码。",
        "",
        "**请按下面步骤操作：**",
        "",
        "1. 打开 GreatLove APP",
        "2. 设置 → AI 助手 → 绑定 OpenClaw",
        `3. 输入验证码：**${res.message.match(/(\d{3}\s?\d{3})/)?.[1] || "(看上面 message)"}**`,
        "4. 点「确认」",
        "",
        res.message,
        "",
        "告诉我做完了，我会继续轮询确认。",
      ];
      return textResult(lines.join("\n"), { qrAttached: !!res.qrDataUrl });
    },
  };
}
